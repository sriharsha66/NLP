from flask import Flask
from flask import Flask,request
from error import ecodes
import sys
import logging
logging.basicConfig(filename='driving_details.log', filemode='a',  format='%(asctime)s - %(levelname)-8s - %(message)s',
    level=logging.INFO,datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger('driving_details')
import datetime

app = Flask(__name__)

from captcha_solver import solve_captcha
from time import sleep, time
import time 


from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
chrome_options = Options()
chrome_options.add_argument("--headless")


# def data_ext():

   
def gen_resp(code,desc,drivig_data):
    resp = {
        'respcode': code,
        'respdesc': desc,
        'data':drivig_data
    }
    return resp

@app.route("/dl",methods=["POST"])
def predict():
    # data()
    if not ('Content-Type' in request.headers and request.headers['Content-Type']=='application/json'):
        logger.info("invalid headers")
        return gen_resp("400",ecodes['400'],None)
    req = request.json
    try:
        try:
            if not req:
                print(req)
            try:
                dlno = req['dl_no']         
                dob = req['dob']
                txnid = req['txnid']                
                try:                        
                    d= datetime.datetime.strptime(dob,'%d-%M-%Y') # Regex for the dob format
                except Exception as e:
                    logger.error(f'invalid dob : ',exc_info=True)
                    return gen_resp("405",ecodes['405'],None)
                if not (len(dlno) ==16) :                        # in [16] and dlno.isalnum())
                    logger.error(f'invalid fileno :{dlno}' )
                    return gen_resp("406",ecodes['406'],None)            
                try:
                    st = time.time()
                    driver= webdriver.Chrome("./chromedriver",options=chrome_options) 

                    driver.get('https://parivahan.gov.in/rcdlstatus/?pur_cd=101')
                    driver.maximize_window()

                    driving_no = '//*[@id="form_rcdl:tf_dlNO"]'
                    WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.XPATH, driving_no)))
                    driver.find_element_by_xpath(driving_no).send_keys(dlno)

                    dob_no = '//*[@id="form_rcdl:tf_dob_input"]'
                    a = driver.find_element_by_xpath(dob_no).send_keys(dob)
                    print(f'dob entered:{a}')

                    print(f'time taken for laoding selenium web page : {time.time() - st}')
                    solve_captcha(driver, "Welcome to DL")
          

                    WebDriverWait(driver, 20).until(
                            EC.presence_of_element_located((By.XPATH, '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div')))

                    current_status = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[1]/tbody/tr[1]/td[2]/span'  
                    a1 = driver.find_element_by_xpath(current_status).text
                    print(f'current_status:{a1}')

                    holders_name = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[1]/tbody/tr[2]/td[2]'
                    a2 = driver.find_element_by_xpath(holders_name).text
                    print(f'holders_name:{a2}')

                    old_new_dl = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[1]/tbody/tr[3]/td[2]'
                    a3 = driver.find_element_by_xpath(old_new_dl).text
                    print(f'old_new_dl_no:{a3}')

                    source_of_data = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[1]/tbody/tr[4]/td[2]'
                    a4 = driver.find_element_by_xpath(source_of_data).text
                    print(f'source_of_data:{a4}')

                    issu_date = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[2]/tbody/tr[1]/td[2]'   
                    a5= driver.find_element_by_xpath(issu_date).text
                    print(f'issue_date:{a5}')

                    issuinr_office = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[2]/tbody/tr[2]/td[2]'
                    a6= driver.find_element_by_xpath(issuinr_office).text
                    print(f'issuing_office:{a6}')

                    last_endorsed_date = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[3]/tbody/tr[1]/td[2]'
                    a7= driver.find_element_by_xpath(last_endorsed_date).text
                    print(f'last_endorsed_date:{a7}')

                    last_endorsed_office = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[3]/tbody/tr[2]/td[2]'
                    a8= driver.find_element_by_xpath(last_endorsed_office).text
                    print(f'last_endorsed_office:{a8}')

                    lat_completed_transaction = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[3]/tbody/tr[3]/td[2]'
                    a9= driver.find_element_by_xpath(lat_completed_transaction).text
                    print(f'last_completed_transaction:{a9}')

                    from_date = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[4]/tbody/tr[1]/td[2]' # non-transport
                    a10 = driver.find_element_by_xpath(from_date).text
                    print(f'from_date_non-transport:{a10}')

                    to_date = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[4]/tbody/tr[1]/td[3]'
                    a11 = driver.find_element_by_xpath(to_date).text
                    print(f'to_date_non-transport:{a11}')

                    from_date1 = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[4]/tbody/tr[2]/td[2]'
                    a12 = driver.find_element_by_xpath(from_date1).text
                    print(f'from_date_transport:{a12}')

                    to_date1 = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[4]/tbody/tr[2]/td[3]'
                    a13 =  driver.find_element_by_xpath(to_date1).text
                    print(f'to_date_transport:{a13}')

                    hazardous_valid_till = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[5]/tbody/tr/td[2]'
                    a14 = driver.find_element_by_xpath(hazardous_valid_till).text
                    print(f'hazardous_valid_till:{a14}')

                    hill_valid_till = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/table[5]/tbody/tr/td[4]'
                    a15 = driver.find_element_by_xpath(hill_valid_till).text
                    print(f'hill_valid_till:{a15}')

                    cov_category = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/div[6]/div/table/tbody/tr[1]/td[1]'
                    a16 = driver.find_element_by_xpath(cov_category).text
                    print(f'cov_category:{a16}')

                    cov_category1 = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/div[6]/div/table/tbody/tr[2]/td[1]'
                    a17 = driver.find_element_by_xpath(cov_category1).text
                    print(f'cov_category1:{a17}')

                    class_of_vehicle = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/div[6]/div/table/tbody/tr[1]/td[2]'
                    a18 = driver.find_element_by_xpath(class_of_vehicle).text
                    print(f'class_of_vehicle:{a18}')

                    class_of_vehicle1 = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/div[6]/div/table/tbody/tr[2]/td[2]'
                    a19 = driver.find_element_by_xpath(class_of_vehicle1).text
                    print(f'class_of_vehicle:{a19}')

                    cov_iddue_date = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/div[6]/div/table/tbody/tr[1]/td[3]'
                    a20 = driver.find_element_by_xpath(cov_iddue_date).text
                    print(f'cov_iddue_date:{a20}')

                    cov_iddue_date1 = '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/span/div/div/div/div/div/div[6]/div/table/tbody/tr[1]/td[3]'
                    a21 = driver.find_element_by_xpath(cov_iddue_date1).text
                    print(f'cov_iddue_date1:{a21}')

                    # print(f'data came')
                    drivig_data = {
                    "details_of_driving_license":{
                            "current_status":a1,
                            "holders_name":a2,
                            "old_new_dl.no":a3,
                            "source_of_data":a4
                    },
                    "driving_license_initial_details":{
                            "initial_issue_date":a5,
                            "initial_issuing_office":a6,
                    },
                    "driving_license_endorsed_details":{
                            "last_endorsed_date":a7,
                            "last_endorsed_office":a8,
                            "last_completed_transaction":a9
                    },
                    "driving_license_validity_details":{
                            "non_transport":a10,
                            "non_transport_1":a11,
                            "transport":a12,
                            "transport_1":a13
                    },
                    "class_of_vehicle_details":{
                            "hazardous_valid_till":a14,
                            "hill_valid_till":a15,
                            "cov_category":a16,
                            "cov_category_1":a17,
                            "class_of_vehicle":a18,
                            "class_of_vehicle_1":a19,
                            "cov_issue_date":a20,
                            "cov_issue_date_1":a21
                    },  
                    }               
                    data = drivig_data
                    return gen_resp("200",ecodes['200'],data)
                except Exception as e:                   
                    logger.info(f'error_transaction_id:{txnid} :request netwwork error : {e}')
                    return gen_resp("503",ecodes['503'],None)   
    
            except KeyError as ke:
                logger.error(f'missing one or more parameters : {sys.exc_info()}')
                return gen_resp("402",ecodes['402'],None)
                
        except TypeError as l:
            logger.error(f'invalid_request : {sys.exc_info()}')
            return gen_resp("401",ecodes['401'],None)

    except Exception as e :
        logger.error(f'Global Error : {sys.exc_info()}')
        return gen_resp("500",ecodes['500'],None)


@app.errorhandler(400) 
def invalid_route(e):
    logger.error(f'invalid (empty body request or not in json format)')
    return gen_resp("401",ecodes['401'],None)

@app.errorhandler(500) 
def invalid_route(e): 
    return gen_resp("500",ecodes['500'],None)     
       


if __name__ == '__main__':
    app.run(host="localhost", port=5000, debug=True)