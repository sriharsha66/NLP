from time import sleep
import random

import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'
# Conver to base64
import base64

# Selenium Libraries
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

# OCR Libraries

from paddleocr import PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en',use_gpu=False)
# import easyocr
# ocr = easyocr.Reader(['ch_sim','en']) # this needs to run only once to load the model into memory
# # ocr.readtext('PAN Card.jpeg')

def get_captcha(driver):
    # sleep(random.randint(8,10))

    # find the captcha image
    # Plase replace yout captcha image Xpath here

    search_captchaImage = WebDriverWait(driver,5).until(
        EC.presence_of_element_located((By.XPATH,'html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[3]/div/div[2]/div/div[2]/table/tbody/tr/td[1]/img')))   
        # //*[@id="form_rcdl:j_idt38:j_idt44"]
    print(f'came to solve captcha') # //*[@id="form_rcdl:j_idt36:j_idt44"]  /html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[3]/div/div[2]/div/div[2]/table/tbody/tr/td[1]/img

    # get the captcha as a base64 string
    img_captcha_base64 = driver.execute_async_script("""
        var ele = arguments[0], callback = arguments[1];
        ele.addEventListener('load', function fn(){
        ele.removeEventListener('load', fn, false);
        var cnv = document.createElement('canvas');
        cnv.width = this.width; cnv.height = this.height;
        cnv.getContext('2d').drawImage(this, 0, 0);
        callback(cnv.toDataURL('image/jpeg').substring(22));
        }, false);
        ele.dispatchEvent(new Event('load'));
        """, search_captchaImage)

    # Download and save a captcha image with name captcha.jpg in this directory
    # save the captcha to a file
    with open(r"captcha.jpg", 'wb') as f:
        f.write(base64.b64decode(img_captcha_base64))

    print("Done with image process")

    # need to run only once to download and load model into memory
    img_path = 'captcha.jpg'
    
    try:
        captcha = ocr.ocr(img_path, cls=False)[0][1][0].replace(" ", "")
        print(captcha)
        # sleep(200)
        return captcha
    except:
        return None


def solve_captcha(driver, elem):
    solved = False
    while solved == False:
        # get captcha
        result = get_captcha(driver)

        print(f'solved captach page {result}')
        if result != None:                    
            captcha = result

            # find input captcha element
            # Enter input captcha XPATH here
            search = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.XPATH, '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[3]/div/div[2]/div/div[2]/table/tbody/tr/td[3]/input')))  
                # //*[@id="form_rcdl:j_idt36:CaptchaID"]

            # Enter Captcha in the input box
            search.send_keys(str(captcha))
            # sleep(random.randint(5, 10))

            # Find send Submit button
            submit = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, '/html/body/form/div[1]/div[3]/div[1]/div/div[2]/div[4]/div/button[1]')))   # //*[@id="form_rcdl:j_idt49"] //*[@id="form_rcdl:j_idt49"]
            # Click send OTP
            submit.click()  
            print('Submit Clicked')
            # try:                    
            #     error_data = WebDriverWait(driver, 3).until(
            #        EC.presence_of_element_located((By.XPATH,'/html/body/div[4]/div[1]')))
            #     if error_data:
            #         solved = True
            # except:
            #     pass 

            try:
                # Find Text to confirm we are redirected to next page and login successfully
                alert_success = WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.XPATH, '//*[@id="logo"]/a/img')))  

                if alert_success:
                    solved = True
            except:
                pass
