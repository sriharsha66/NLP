ecodes={
    "200" : "success",
    "400" : "invalid headers",
    "401" : "invalid request",
    "402" : "missing one or more parameters",
    "403" : "invalid company name",
    "404" : "multiple companies found",
    "405" : "invalid dob",
    "406" : "invalid dl_no",
    "503" : "please check dob or driving_license_number",
    "500" : "something went wrong,please try again"
    }

  